ArchiveMedia
============

Double-click: ArchiveMedia.bat

What it does
------------
- Checks for winget.
- Installs PowerShell 7 if missing.
- Installs FFmpeg/FFprobe (Gyan.FFmpeg) if missing.
- Installs ImageMagick if missing.
- Asks for INPUT and OUTPUT folders.
- Recursively preserves the folder tree.
- Detects CPU/GPU and tests available NVIDIA/Intel/AMD hardware encoders.
- Prefers hardware AV1, then HEVC, then H.264; libx265 is the CPU fallback.
- Uses up to 4 parallel jobs by default.
- Video:
  * Output extension is .mp4.
  * Videos above 1080p are resized to a 1920x1080-equivalent box.
  * 1080p threshold: 6 Mb/s -> target 5 Mb/s.
  * 720p threshold: 3.5 Mb/s -> target 3 Mb/s.
  * SD threshold: 2 Mb/s -> target 1.5 Mb/s.
  * >45 fps gets 1.5x bitrate.
  * Existing MP4 below threshold is copied byte-for-byte.
  * Other low-bitrate containers are remuxed to MP4 when possible.
  * AAC audio is copied; incompatible audio is encoded to AAC 128 kb/s.
  * Variable frame rate and phone rotation metadata are preserved.
- Photos:
  * Output extension is .jpg.
  * Existing JPG/JPEG already within the 4096x2160-equivalent limit is copied byte-for-byte.
  * Larger/non-JPEG photos are auto-oriented, resized if necessary, and encoded as JPEG quality 97, 4:4:4.
  * Portrait photos use a 2160x4096-equivalent limit.
- Camera RAW files are copied unchanged.
- Other/unrecognized files are copied unchanged.
- Stops before processing if two source files would map to the same standardized output filename.
- Reports total file count and total size before/after.
- Failed files are listed in ArchiveMedia_errors.txt.

Important
---------
JPEG conversion/resizing is not mathematically lossless. Existing in-limit JPEG files are copied unchanged.
Always verify the output before deleting the source archive.


v3 fix
------
- Fixed final statistics crash when zero files succeeded.
- Final report now exposes the real per-file FFmpeg/ImageMagick failure instead of hiding it behind a summary error.


v4 fix
------
- NVIDIA AV1 now uses p7 + UHQ + full-resolution multipass + p010le (10-bit), matching the previously verified RTX 5070 Ti command path.
- NVIDIA HEVC gets the same 10-bit UHQ path; H.264 remains 8-bit.
- FFmpeg errors and the exact generated command are now printed directly in the console as well as written to ArchiveMedia_errors.txt.
- Native FFmpeg failures can no longer be hidden by PowerShell ErrorActionPreference.


v5 fix
------
- Fixed PowerShell automatic-variable collision: internal FFmpeg argument lists no longer use the reserved $args variable.
- This fixes: Exception calling "Add" with "1" argument(s): "Collection was of a fixed size."


v6 fix
------
- Fixed the remaining PowerShell automatic-variable collision inside Invoke-Ffmpeg.
- The function parameter is now $CommandArgs instead of $Args.
- Every FFmpeg helper call now explicitly uses -CommandArgs, avoiding positional array binding ambiguity.
- This fixes FFmpeg launching with no arguments and printing only its usage screen.


v7 performance update
---------------------
- Analysis is now parallel instead of one file at a time.
- Worker counts are automatic on every PC; there are no CPU/GPU-model-specific values.
- Auto concurrency uses logical CPU count and best-effort source-drive HDD/SSD detection.
- Encoding concurrency is automatic and separate from analysis concurrency.
- Image analysis uses ImageMagick "identify -ping" so dimensions/orientation can be read without fully decoding the photo.
- FFprobe requests only metadata fields required by the bitrate/resolution policy.
- Unrecognized/non-media files are copied without wasting an FFprobe process on them.
- Removed the second full directory-tree traversal; destination directories are created from analyzed files.


v8 fix
------
- Fixed passthrough files with extensionless/dot filenames such as .stignore.
- Passthrough files and already-good JPEG/MP4 files now copy directly to their final preserved path using System.IO.File.Copy.
- Converted media uses GUID-based temporary filenames and System.IO.File.Move for robust finalization.
- Parallel auto-scaled analysis from v7 is retained.


v9 fix
------
- Removed the remaining Get-Item lookup after analysis.
- Hidden/system/dot files such as .stignore now use System.IO.FileInfo directly.
- v8 direct-copy handling and v7 automatic parallel analysis/encoding are retained.
