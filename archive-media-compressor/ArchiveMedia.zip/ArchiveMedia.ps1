﻿#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------- MEDIA SETTINGS ----------------
# Re-encode threshold / output target. Bitrates are bits per second.
$Threshold1080 = 6000000
$Target1080    = 5000000

$Threshold720  = 3500000
$Target720     = 3000000

$ThresholdSD   = 2000000
$TargetSD      = 1500000

# >45 fps gets more bitrate.
$HighFpsMultiplier = 1.50

# Existing JPG/JPEG files within the size limit are copied byte-for-byte.
# Other still images are converted to high-quality 4:4:4 JPEG.
$JpegQuality = 97
# --------------------------------------------------------

$RawExtensions = @(
    ".3fr", ".arw", ".cr2", ".cr3", ".dcr", ".dng", ".erf", ".fff",
    ".iiq", ".k25", ".kdc", ".mef", ".mos", ".mrw", ".nef", ".nrw",
    ".orf", ".pef", ".raf", ".raw", ".rw2", ".rwl", ".sr2", ".srf",
    ".srw", ".x3f"
)

$PhotoExtensions = @(
    ".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp", ".bmp",
    ".tif", ".tiff", ".avif", ".jxl"
)


# Broad list used to avoid wasting FFprobe launches on unrelated files.
# Unknown extensions are preserved unchanged rather than being destructively guessed.
$VideoExtensions = @(
    ".mp4", ".mov", ".qt", ".m4v", ".mkv", ".webm", ".avi", ".wmv",
    ".asf", ".flv", ".f4v", ".3gp", ".3g2", ".mts", ".m2ts", ".ts",
    ".m2t", ".mpeg", ".mpg", ".mpe", ".mpv", ".m2v", ".vob", ".vro",
    ".ogv", ".ogm", ".mxf", ".dv", ".rm", ".rmvb", ".divx", ".xvid",
    ".h264", ".264", ".h265", ".265", ".hevc", ".av1", ".ivf", ".nut"
)

function Write-Section([string]$Text) {
    Write-Host ""
    Write-Host "=== $Text ===" -ForegroundColor Cyan
}

function Format-Bytes([Int64]$Bytes) {
    if ($Bytes -ge 1TB) { return "{0:N2} TiB" -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return "{0:N2} GiB" -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return "{0:N2} MiB" -f ($Bytes / 1MB) }
    if ($Bytes -ge 1KB) { return "{0:N2} KiB" -f ($Bytes / 1KB) }
    return "$Bytes B"
}

function Select-Folder([string]$Title) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = [System.Windows.Forms.FolderBrowserDialog]::new()
        $dialog.Description = $Title
        $dialog.ShowNewFolderButton = $true
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            return [IO.Path]::GetFullPath($dialog.SelectedPath).TrimEnd("\")
        }
    }
    catch {
        # Fall back to console input.
    }

    $p = (Read-Host $Title).Trim().Trim('"')
    if ([string]::IsNullOrWhiteSpace($p)) { return $null }
    return [IO.Path]::GetFullPath($p).TrimEnd("\")
}

function Resolve-Executable([string]$Name, [string[]]$FallbackPatterns = @()) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $wingetLink = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\$Name"
    if (Test-Path -LiteralPath $wingetLink) {
        return (Get-Item -LiteralPath $wingetLink).FullName
    }

    foreach ($pattern in $FallbackPatterns) {
        $matches = Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        if ($matches) { return $matches[0].FullName }
    }
    return $null
}

function Install-WingetPackage([string]$Id, [string]$FriendlyName) {
    Write-Host "Installing $FriendlyName..." -ForegroundColor Yellow
    & winget install --id $Id --exact --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "winget failed to install $FriendlyName ($Id). Exit code: $LASTEXITCODE"
    }
}

function Test-Encoder([string]$FFmpeg, [string]$Encoder) {
    & $FFmpeg -hide_banner -loglevel error -f lavfi -i "color=c=black:s=320x180:r=30" `
        -frames:v 3 -c:v $Encoder -f null NUL 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Get-VideoPolicy(
    [int]$Width,
    [int]$Height,
    [double]$Fps,
    [Int64]$Bitrate,
    [string]$Codec
) {
    $longSide  = [Math]::Max($Width, $Height)
    $shortSide = [Math]::Min($Width, $Height)
    $pixels = [Int64]$Width * [Int64]$Height

    # Anything above a 1920x1080-equivalent box is reduced to 1080p.
    $needsResize = ($longSide -gt 1920 -or $shortSide -gt 1080)

    if ($pixels -ge 1400000 -or $longSide -ge 1600) {
        $threshold = [double]$script:Threshold1080
        $target = [double]$script:Target1080
        $bucket = "1080p"
    }
    elseif ($pixels -ge 600000 -or $longSide -ge 1100) {
        $threshold = [double]$script:Threshold720
        $target = [double]$script:Target720
        $bucket = "720p"
    }
    else {
        $threshold = [double]$script:ThresholdSD
        $target = [double]$script:TargetSD
        $bucket = "SD"
    }

    if ($Fps -gt 45) {
        $threshold *= $script:HighFpsMultiplier
        $target *= $script:HighFpsMultiplier
    }

    # H.264 needs a little more bitrate than HEVC/AV1 for similar quality.
    # For output encoding, the target is adjusted later if the selected encoder is H.264.
    $codecLower = $Codec.ToLowerInvariant()
    if ($codecLower -in @("av1", "hevc", "h265")) {
        # Keep our own ~5 Mb/s AV1/HEVC outputs from being needlessly encoded again.
        $threshold *= 1.05
    }

    [pscustomobject]@{
        NeedsResize = $needsResize
        Threshold   = [Int64][Math]::Round($threshold)
        Target      = [Int64][Math]::Round($target)
        Bucket      = $bucket
        Bitrate     = $Bitrate
    }
}

function Get-Fps([string]$Rate) {
    if ([string]::IsNullOrWhiteSpace($Rate) -or $Rate -eq "0/0") { return 0.0 }
    if ($Rate -match "^(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)$") {
        $n = [double]$Matches[1]
        $d = [double]$Matches[2]
        if ($d -ne 0) { return $n / $d }
    }
    $v = 0.0
    if ([double]::TryParse($Rate, [ref]$v)) { return $v }
    return 0.0
}

function Get-RelativePathSafe([string]$Root, [string]$Path) {
    return [IO.Path]::GetRelativePath($Root, $Path)
}

function Get-OutputPath(
    [string]$InputRoot,
    [string]$OutputRoot,
    [IO.FileInfo]$File,
    [string]$Kind
) {
    $relative = Get-RelativePathSafe $InputRoot $File.FullName
    $relativeDir = [IO.Path]::GetDirectoryName($relative)
    $base = [IO.Path]::GetFileNameWithoutExtension($relative)

    switch ($Kind) {
        "Video" { $name = "$base.mp4" }
        "Photo" { $name = "$base.jpg" }
        default { $name = [IO.Path]::GetFileName($relative) }
    }

    if ([string]::IsNullOrEmpty($relativeDir)) {
        return Join-Path $OutputRoot $name
    }
    return Join-Path (Join-Path $OutputRoot $relativeDir) $name
}


function Get-SourceMediaType([string]$Path) {
    # Best-effort mapping of the input drive to Windows' physical-disk media type.
    # Falls back to Unknown for network paths, storage spaces, unusual USB bridges, etc.
    try {
        $root = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($Path))
        if ($root -match "^([A-Za-z]):\\$") {
            $driveLetter = $Matches[1]
            $disk = Get-Partition -DriveLetter $driveLetter -ErrorAction Stop |
                Get-Disk -ErrorAction Stop |
                Select-Object -First 1

            if ($disk) {
                $physical = Get-PhysicalDisk -ErrorAction SilentlyContinue |
                    Where-Object {
                        ([string]$_.DeviceId -eq [string]$disk.Number) -or
                        ($_.FriendlyName -eq $disk.FriendlyName)
                    } |
                    Select-Object -First 1

                if ($physical -and $physical.MediaType) {
                    $media = [string]$physical.MediaType
                    if ($media -match "SSD") { return "SSD" }
                    if ($media -match "HDD") { return "HDD" }
                }
            }
        }
    }
    catch {
        # Auto mode deliberately continues when storage mapping is unavailable.
    }
    return "Unknown"
}

function Get-AutoConcurrency(
    [int]$LogicalProcessors,
    [string]$MediaType,
    [bool]$HardwareEncoding
) {
    $logical = [Math]::Max(1, $LogicalProcessors)

    # Analysis consists mostly of short external metadata probes.
    # SSDs tolerate much more probe concurrency; rotational disks are deliberately
    # capped lower to avoid turning useful reads into seek thrashing.
    switch ($MediaType) {
        "SSD" {
            $analysis = [Math]::Min(64, [Math]::Max(4, $logical * 2))
        }
        "HDD" {
            $analysis = [Math]::Min(12, [Math]::Max(2, [Math]::Ceiling($logical / 2.0)))
        }
        default {
            $analysis = [Math]::Min(32, [Math]::Max(2, $logical))
        }
    }

    if (-not $HardwareEncoding) {
        # x265 already uses many CPU threads internally.
        $encode = 1
    }
    else {
        switch ($MediaType) {
            "SSD" {
                $encode = [Math]::Min(8, [Math]::Max(1, [Math]::Ceiling($logical / 4.0)))
            }
            "HDD" {
                $encode = [Math]::Min(4, [Math]::Max(1, [Math]::Ceiling($logical / 5.0)))
            }
            default {
                $encode = [Math]::Min(6, [Math]::Max(1, [Math]::Ceiling($logical / 4.0)))
            }
        }
    }

    return [pscustomobject]@{
        Analysis = [int]$analysis
        Encode   = [int]$encode
    }
}

# ---- Dependencies ----
Write-Section "Dependency check"

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "Windows Package Manager (winget) is missing. Install Microsoft App Installer, then run this again."
}

$FFmpeg = Resolve-Executable "ffmpeg.exe" @(
    "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\ffmpeg.exe"
)
$FFprobe = Resolve-Executable "ffprobe.exe" @(
    "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\ffprobe.exe"
)

if (-not $FFmpeg -or -not $FFprobe) {
    Install-WingetPackage "Gyan.FFmpeg" "FFmpeg"
    $FFmpeg = Resolve-Executable "ffmpeg.exe" @(
        "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\ffmpeg.exe"
    )
    $FFprobe = Resolve-Executable "ffprobe.exe" @(
        "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg*\**\ffprobe.exe"
    )
}
if (-not $FFmpeg -or -not $FFprobe) {
    throw "FFmpeg/FFprobe were installed but could not be located."
}

$Magick = Resolve-Executable "magick.exe" @(
    "$env:ProgramFiles\ImageMagick-*\magick.exe",
    "${env:ProgramFiles(x86)}\ImageMagick-*\magick.exe"
)
if (-not $Magick) {
    Install-WingetPackage "ImageMagick.ImageMagick" "ImageMagick"
    $Magick = Resolve-Executable "magick.exe" @(
        "$env:ProgramFiles\ImageMagick-*\magick.exe",
        "${env:ProgramFiles(x86)}\ImageMagick-*\magick.exe"
    )
}
if (-not $Magick) {
    throw "ImageMagick was installed but magick.exe could not be located."
}

Write-Host "FFmpeg:     $FFmpeg"
Write-Host "FFprobe:    $FFprobe"
Write-Host "ImageMagick:$Magick"

# ---- Source / destination ----
Write-Section "Folders"
$InputRoot = Select-Folder "Select INPUT folder"
if (-not $InputRoot) { throw "No input folder selected." }
if (-not (Test-Path -LiteralPath $InputRoot -PathType Container)) {
    throw "Input folder does not exist: $InputRoot"
}

$OutputRoot = Select-Folder "Select OUTPUT folder"
if (-not $OutputRoot) { throw "No output folder selected." }

if ([string]::Equals(
    [IO.Path]::GetFullPath($InputRoot).TrimEnd("\"),
    [IO.Path]::GetFullPath($OutputRoot).TrimEnd("\"),
    [StringComparison]::OrdinalIgnoreCase
)) {
    throw "Input and output folders must be different. This protects the originals."
}

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null

Write-Host "Input:  $InputRoot"
Write-Host "Output: $OutputRoot"

# ---- Hardware detection ----
Write-Section "Hardware detection"
$CpuNames = @(Get-CimInstance Win32_Processor | ForEach-Object Name)
$GpuNames = @(Get-CimInstance Win32_VideoController | ForEach-Object Name)

Write-Host ("CPU: " + ($CpuNames -join " | "))
Write-Host ("GPU: " + ($GpuNames -join " | "))

$gpuText = ($GpuNames -join " ").ToLowerInvariant()
$encoderCandidates = [System.Collections.Generic.List[string]]::new()

if ($gpuText -match "nvidia") {
    @("av1_nvenc", "hevc_nvenc", "h264_nvenc") | ForEach-Object { $encoderCandidates.Add($_) }
}
if ($gpuText -match "intel") {
    @("av1_qsv", "hevc_qsv", "h264_qsv") | ForEach-Object {
        if (-not $encoderCandidates.Contains($_)) { $encoderCandidates.Add($_) }
    }
}
if ($gpuText -match "amd|radeon") {
    @("av1_amf", "hevc_amf", "h264_amf") | ForEach-Object {
        if (-not $encoderCandidates.Contains($_)) { $encoderCandidates.Add($_) }
    }
}

# If vendor detection is incomplete, still try all common hardware backends.
@(
    "av1_nvenc", "av1_qsv", "av1_amf",
    "hevc_nvenc", "hevc_qsv", "hevc_amf",
    "h264_nvenc", "h264_qsv", "h264_amf"
) | ForEach-Object {
    if (-not $encoderCandidates.Contains($_)) { $encoderCandidates.Add($_) }
}

$SelectedEncoder = $null
foreach ($enc in $encoderCandidates) {
    Write-Host "Testing $enc..." -NoNewline
    if (Test-Encoder $FFmpeg $enc) {
        $SelectedEncoder = $enc
        Write-Host " OK" -ForegroundColor Green
        break
    }
    Write-Host " unavailable" -ForegroundColor DarkGray
}

if (-not $SelectedEncoder) {
    if (Test-Encoder $FFmpeg "libx265") {
        $SelectedEncoder = "libx265"
    }
    else {
        throw "No usable hardware encoder and no libx265 fallback were found."
    }
}

$OutputCodecClass =
    if ($SelectedEncoder -match "^av1_") { "AV1" }
    elseif ($SelectedEncoder -match "^hevc_" -or $SelectedEncoder -eq "libx265") { "HEVC" }
    else { "H264" }

$LogicalProcessors = [Environment]::ProcessorCount
$SourceMediaType = Get-SourceMediaType $InputRoot
$HardwareEncoding = ($SelectedEncoder -ne "libx265")
$Concurrency = Get-AutoConcurrency $LogicalProcessors $SourceMediaType $HardwareEncoding
$AnalysisParallel = $Concurrency.Analysis
$EncodeParallel = $Concurrency.Encode

Write-Host "Selected encoder: $SelectedEncoder ($OutputCodecClass)" -ForegroundColor Green
Write-Host "Logical CPUs:     $LogicalProcessors"
Write-Host "Source storage:   $SourceMediaType"
Write-Host "Analysis workers: $AnalysisParallel (auto)"
Write-Host "Encode workers:   $EncodeParallel (auto)"

# ---- Scan ----
Write-Section "Scanning"

$outputPrefix = [IO.Path]::GetFullPath($OutputRoot).TrimEnd("\") + "\"

# One recursive filesystem walk. Output is excluded when it lives below input.
$allFiles = @(
    Get-ChildItem -LiteralPath $InputRoot -File -Recurse -Force |
    Where-Object {
        -not $_.FullName.StartsWith($outputPrefix, [StringComparison]::OrdinalIgnoreCase)
    }
)

if ($allFiles.Count -eq 0) {
    throw "No files found under: $InputRoot"
}

Write-Host "Files discovered: $($allFiles.Count)"
Write-Host "Analyzing with $AnalysisParallel worker(s)..."

$completedAnalysis = 0

# Copy scalar settings once so parallel runspaces can consume them efficiently.
$analysisFFprobe = $FFprobe
$analysisMagick = $Magick
$analysisRawExtensions = $RawExtensions
$analysisPhotoExtensions = $PhotoExtensions
$analysisVideoExtensions = $VideoExtensions
$analysisOutputCodecClass = $OutputCodecClass
$analysisThreshold1080 = $Threshold1080
$analysisTarget1080 = $Target1080
$analysisThreshold720 = $Threshold720
$analysisTarget720 = $Target720
$analysisThresholdSD = $ThresholdSD
$analysisTargetSD = $TargetSD
$analysisHighFpsMultiplier = $HighFpsMultiplier

$analysisResults = @(
    $allFiles |
    ForEach-Object -Parallel {
        $file = $_

        $ffprobePath = $using:analysisFFprobe
        $magickPath = $using:analysisMagick
        $rawExtensions = $using:analysisRawExtensions
        $photoExtensions = $using:analysisPhotoExtensions
        $videoExtensions = $using:analysisVideoExtensions
        $outputCodecClass = $using:analysisOutputCodecClass

        $threshold1080 = [Int64]$using:analysisThreshold1080
        $target1080 = [Int64]$using:analysisTarget1080
        $threshold720 = [Int64]$using:analysisThreshold720
        $target720 = [Int64]$using:analysisTarget720
        $thresholdSD = [Int64]$using:analysisThresholdSD
        $targetSD = [Int64]$using:analysisTargetSD
        $highFpsMultiplier = [double]$using:analysisHighFpsMultiplier

        $ext = $file.Extension.ToLowerInvariant()
        $kind = "Passthrough"
        $action = "Copy"
        $details = ""
        $targetBitrate = 0L
        $needsResize = $false
        $videoCodec = ""
        $videoBitrate = 0L
        $fps = 0.0
        $width = 0
        $height = 0
        $allAudioAAC = $true

        if ($rawExtensions -contains $ext) {
            $kind = "RAW"
            $action = "Copy"
            $details = "RAW copied unchanged"
        }
        elseif ($photoExtensions -contains $ext) {
            $kind = "Photo"

            # -ping reads image headers/metadata without decoding the full image.
            $photoInfo = & $magickPath identify -ping -format "%w|%h|%[orientation]" $file.FullName 2>$null
            if ($LASTEXITCODE -ne 0 -or -not $photoInfo) {
                $kind = "Passthrough"
                $action = "Copy"
                $details = "ImageMagick could not identify image; copied unchanged"
            }
            else {
                $firstInfo = ($photoInfo | Select-Object -First 1).ToString().Trim()
                $parts = $firstInfo -split "\|"
                if ($parts.Count -ge 2) {
                    $width = [int]$parts[0]
                    $height = [int]$parts[1]
                }

                # Account for EXIF 90/270-degree orientation without auto-orienting
                # (and therefore decoding) the entire photo during analysis.
                if ($parts.Count -ge 3) {
                    $orientation = [string]$parts[2]
                    if ($orientation -in @("LeftTop", "RightTop", "RightBottom", "LeftBottom")) {
                        $tmp = $width
                        $width = $height
                        $height = $tmp
                    }
                }

                $longSide = [Math]::Max($width, $height)
                $shortSide = [Math]::Min($width, $height)
                $photoTooLarge = ($longSide -gt 4096 -or $shortSide -gt 2160)

                if (($ext -eq ".jpg" -or $ext -eq ".jpeg") -and -not $photoTooLarge) {
                    $action = "CopyPhoto"
                    $details = "JPEG already within 4K limit; byte-for-byte copy"
                }
                else {
                    $action = "ConvertPhoto"
                    $details = if ($photoTooLarge) {
                        "Convert to JPG + resize to 4096x2160-equivalent"
                    }
                    else {
                        "Convert to JPG"
                    }
                }
            }
        }
        elseif ($videoExtensions -contains $ext) {
            # Ask FFprobe only for fields the policy actually needs.
            $probeJson = & $ffprobePath -v error `
                -show_entries "stream=codec_type,codec_name,width,height,avg_frame_rate,bit_rate:format=duration,bit_rate" `
                -of json -- $file.FullName 2>$null

            if ($LASTEXITCODE -eq 0 -and $probeJson) {
                try {
                    $probe = ($probeJson -join "`n") | ConvertFrom-Json
                    $video = @($probe.streams | Where-Object codec_type -eq "video") |
                        Select-Object -First 1

                    if ($video) {
                        $kind = "Video"
                        $width = [int]$video.width
                        $height = [int]$video.height
                        $videoCodec = [string]$video.codec_name

                        $rate = [string]$video.avg_frame_rate
                        if (-not [string]::IsNullOrWhiteSpace($rate) -and $rate -ne "0/0") {
                            if ($rate -match "^(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)$") {
                                $n = [double]$Matches[1]
                                $d = [double]$Matches[2]
                                if ($d -ne 0) { $fps = $n / $d }
                            }
                            else {
                                $parsedRate = 0.0
                                if ([double]::TryParse($rate, [ref]$parsedRate)) {
                                    $fps = $parsedRate
                                }
                            }
                        }

                        if ($video.bit_rate) {
                            $videoBitrate = [Int64]$video.bit_rate
                        }
                        elseif ($probe.format.bit_rate) {
                            $videoBitrate = [Int64]$probe.format.bit_rate
                        }
                        elseif ($probe.format.duration -and [double]$probe.format.duration -gt 0) {
                            $videoBitrate = [Int64](($file.Length * 8.0) / [double]$probe.format.duration)
                        }

                        $audioStreams = @($probe.streams | Where-Object codec_type -eq "audio")
                        if ($audioStreams.Count -gt 0) {
                            $allAudioAAC = (@($audioStreams | Where-Object codec_name -ne "aac").Count -eq 0)
                        }

                        $longSide = [Math]::Max($width, $height)
                        $shortSide = [Math]::Min($width, $height)
                        $pixels = [Int64]$width * [Int64]$height
                        $needsResize = ($longSide -gt 1920 -or $shortSide -gt 1080)

                        if ($pixels -ge 1400000 -or $longSide -ge 1600) {
                            $threshold = [double]$threshold1080
                            $target = [double]$target1080
                        }
                        elseif ($pixels -ge 600000 -or $longSide -ge 1100) {
                            $threshold = [double]$threshold720
                            $target = [double]$target720
                        }
                        else {
                            $threshold = [double]$thresholdSD
                            $target = [double]$targetSD
                        }

                        if ($fps -gt 45) {
                            $threshold *= $highFpsMultiplier
                            $target *= $highFpsMultiplier
                        }

                        $codecLower = $videoCodec.ToLowerInvariant()
                        if ($codecLower -in @("av1", "hevc", "h265")) {
                            $threshold *= 1.05
                        }

                        $targetBitrate = [Int64][Math]::Round($target)

                        if ($outputCodecClass -eq "H264") {
                            $targetBitrate = [Int64][Math]::Round($targetBitrate * 1.40)
                        }
                        elseif ($outputCodecClass -eq "HEVC") {
                            $targetBitrate = [Int64][Math]::Round($targetBitrate * 1.10)
                        }

                        $isMp4 = ($ext -eq ".mp4")

                        if ($needsResize) {
                            $action = "EncodeVideo"
                            $details = "Above 1080p -> resize + encode"
                        }
                        elseif ($videoBitrate -gt 0 -and $videoBitrate -le [Int64][Math]::Round($threshold)) {
                            if ($isMp4) {
                                $action = "CopyVideo"
                                $details = "Already below bitrate threshold -> byte-for-byte copy"
                            }
                            else {
                                $action = "RemuxVideo"
                                $details = "Already below bitrate threshold -> remux to MP4"
                            }
                        }
                        else {
                            $action = "EncodeVideo"
                            if ($videoBitrate -gt 0) {
                                $details = "Bitrate $([Math]::Round($videoBitrate / 1000000.0, 2)) Mb/s > threshold $([Math]::Round($threshold / 1000000.0, 2)) Mb/s"
                            }
                            else {
                                $details = "Unknown bitrate -> encode conservatively"
                            }
                        }
                    }
                }
                catch {
                    $kind = "Passthrough"
                    $action = "Copy"
                    $details = "FFprobe metadata parse failed; copied unchanged"
                }
            }
            else {
                $kind = "Passthrough"
                $action = "Copy"
                $details = "FFprobe could not read video; copied unchanged"
            }
        }
        else {
            # Non-media/unknown extension: preserve it without launching FFprobe.
            $kind = "Passthrough"
            $action = "Copy"
            $details = "Unrecognized/non-media file copied unchanged"
        }

        [pscustomobject]@{
            Source         = $file.FullName
            FileName       = $file.Name
            Extension      = $file.Extension
            BaseName       = $file.BaseName
            SourceBytes    = [Int64]$file.Length
            CreationTime   = $file.CreationTime
            LastWriteTime  = $file.LastWriteTime
            Kind           = $kind
            Action         = $action
            Details        = $details
            Width          = $width
            Height         = $height
            Fps            = $fps
            Codec          = $videoCodec
            VideoBitrate   = $videoBitrate
            TargetBitrate  = $targetBitrate
            NeedsResize    = $needsResize
            AllAudioAAC    = $allAudioAAC
        }
    } -ThrottleLimit $AnalysisParallel |
    ForEach-Object {
        $completedAnalysis++
        if (($completedAnalysis % 10 -eq 0) -or ($completedAnalysis -eq $allFiles.Count)) {
            Write-Progress -Activity "Analyzing media" `
                -Status "$completedAnalysis / $($allFiles.Count)" `
                -PercentComplete (($completedAnalysis / $allFiles.Count) * 100)
        }
        $_
    }
)
Write-Progress -Activity "Analyzing media" -Completed

$tasks = [System.Collections.Generic.List[object]]::new()
$destinations = [System.Collections.Generic.Dictionary[string,string]]::new(
    [StringComparer]::OrdinalIgnoreCase
)
$collisions = [System.Collections.Generic.List[string]]::new()

foreach ($item in $analysisResults) {
    # Avoid PowerShell provider lookups here: hidden/system/dot files such as
    # .stignore may not be returned unless -Force is used. System.IO handles
    # the exact path directly.
    $sourceFile = [IO.FileInfo]::new([string]$item.Source)
    $dest = Get-OutputPath $InputRoot $OutputRoot $sourceFile $item.Kind
    $destKey = [IO.Path]::GetFullPath($dest)

    if ($destinations.ContainsKey($destKey)) {
        $collisions.Add(
            "OUTPUT COLLISION:`n  $($destinations[$destKey])`n  $($item.Source)`n  -> $destKey"
        )
        continue
    }
    $destinations[$destKey] = $item.Source

    # Create destination directories from actual files instead of walking the
    # source tree a second time.
    $destDir = [IO.Path]::GetDirectoryName($destKey)
    New-Item -ItemType Directory -Path $destDir -Force | Out-Null

    $tasks.Add([pscustomobject]@{
        Source         = $item.Source
        Destination    = $destKey
        Kind           = $item.Kind
        Action         = $item.Action
        Details        = $item.Details
        SourceBytes    = [Int64]$item.SourceBytes
        CreationTime   = $item.CreationTime
        LastWriteTime  = $item.LastWriteTime
        Width          = [int]$item.Width
        Height         = [int]$item.Height
        Fps            = [double]$item.Fps
        Codec          = [string]$item.Codec
        VideoBitrate   = [Int64]$item.VideoBitrate
        TargetBitrate  = [Int64]$item.TargetBitrate
        NeedsResize    = [bool]$item.NeedsResize
        AllAudioAAC    = [bool]$item.AllAudioAAC
    })
}

if ($collisions.Count -gt 0) {
    Write-Host ""
    Write-Host "Two or more source files would map to the same standardized output filename." -ForegroundColor Red
    Write-Host "Nothing has been converted. Resolve these name collisions first:" -ForegroundColor Red
    foreach ($c in $collisions) {
        Write-Host ""
        Write-Host $c -ForegroundColor Yellow
    }
    throw "Output filename collisions detected."
}

[Int64]$beforeBytes = 0
foreach ($t in $tasks) {
    $beforeBytes += [Int64]$t.SourceBytes
}
Write-Host "Files to handle: $($tasks.Count)"
Write-Host "Input size:      $(Format-Bytes $beforeBytes)"

# ---- Parallel processing ----
Write-Section "Processing"

$results = @(
    $tasks | ForEach-Object -Parallel {
        $t = $_
        $ffmpeg = $using:FFmpeg
        $magick = $using:Magick
        $encoder = $using:SelectedEncoder
        $codecClass = $using:OutputCodecClass
        $jpegQuality = $using:JpegQuality

        $destDir = [IO.Path]::GetDirectoryName($t.Destination)
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null

        $ext = [IO.Path]::GetExtension($t.Destination)
        $temp = Join-Path $destDir (".__ArchiveMedia_" + [Guid]::NewGuid().ToString("N") + $ext)
        $directOutput = $false

        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue

        function Set-OutputTimes([string]$Path, [datetime]$Created, [datetime]$Modified) {
            try {
                [IO.File]::SetCreationTime($Path, $Created)
                [IO.File]::SetLastWriteTime($Path, $Modified)
            } catch {}
        }

        function Get-EncoderArgs([string]$Encoder, [Int64]$Target) {
            $maxRate = [Int64][Math]::Round($Target * 1.40)
            $bufSize = [Int64][Math]::Round($Target * 5.60)

            $a = [System.Collections.Generic.List[string]]::new()
            $a.Add("-c:v"); $a.Add($Encoder)

            # NVIDIA AV1/HEVC use the same high-quality path that was verified
            # separately on RTX 50-series hardware.
            if ($Encoder -eq "av1_nvenc") {
                $a.Add("-preset"); $a.Add("p7")
                $a.Add("-tune"); $a.Add("uhq")
                $a.Add("-rc"); $a.Add("vbr")
                $a.Add("-multipass"); $a.Add("fullres")
                $a.Add("-spatial-aq"); $a.Add("1")
                $a.Add("-aq-strength"); $a.Add("8")
                $a.Add("-pix_fmt"); $a.Add("p010le")
            }
            elseif ($Encoder -eq "hevc_nvenc") {
                $a.Add("-preset"); $a.Add("p7")
                $a.Add("-tune"); $a.Add("uhq")
                $a.Add("-rc"); $a.Add("vbr")
                $a.Add("-multipass"); $a.Add("fullres")
                $a.Add("-spatial-aq"); $a.Add("1")
                $a.Add("-aq-strength"); $a.Add("8")
                $a.Add("-pix_fmt"); $a.Add("p010le")
            }
            elseif ($Encoder -eq "h264_nvenc") {
                $a.Add("-preset"); $a.Add("p7")
                $a.Add("-tune"); $a.Add("hq")
                $a.Add("-rc"); $a.Add("vbr")
                $a.Add("-multipass"); $a.Add("fullres")
                $a.Add("-spatial-aq"); $a.Add("1")
                $a.Add("-aq-strength"); $a.Add("8")
                $a.Add("-pix_fmt"); $a.Add("yuv420p")
            }
            elseif ($Encoder -match "_qsv$") {
                $a.Add("-preset"); $a.Add("slow")
                $a.Add("-pix_fmt"); $a.Add("nv12")
            }
            elseif ($Encoder -match "_amf$") {
                $a.Add("-quality"); $a.Add("quality")
                $a.Add("-pix_fmt"); $a.Add("nv12")
            }
            elseif ($Encoder -eq "libx265") {
                $a.Add("-preset"); $a.Add("medium")
                $a.Add("-pix_fmt"); $a.Add("yuv420p10le")
            }
            else {
                $a.Add("-pix_fmt"); $a.Add("yuv420p")
            }

            $a.Add("-b:v"); $a.Add([string]$Target)
            $a.Add("-maxrate"); $a.Add([string]$maxRate)
            $a.Add("-bufsize"); $a.Add([string]$bufSize)
            return $a.ToArray()
        }

        function Invoke-Ffmpeg {
            param(
                [Parameter(Mandatory = $true)]
                [string[]]$CommandArgs
            )

            $displayArgs = foreach ($arg in $CommandArgs) {
                if ($arg -match '[\s"]') {
                    '"' + ($arg -replace '"', '\"') + '"'
                }
                else {
                    $arg
                }
            }
            $displayCommand = '"' + $ffmpeg + '" ' + ($displayArgs -join ' ')

            # Do not allow the script-wide Stop preference to hide FFmpeg's own
            # diagnostic output on a non-zero native-process exit.
            $oldPreference = $ErrorActionPreference
            $ErrorActionPreference = "Continue"
            try {
                $msg = & $ffmpeg @CommandArgs 2>&1
                $code = $LASTEXITCODE
            }
            catch {
                $code = if ($LASTEXITCODE) { $LASTEXITCODE } else { 1 }
                $msg = @($_.Exception.Message)
            }
            finally {
                $ErrorActionPreference = $oldPreference
            }

            return [pscustomobject]@{
                ExitCode = $code
                Message  = (($msg | Select-Object -Last 80) -join "`n")
                Command  = $displayCommand
            }
        }

        try {
            switch ($t.Action) {
                "Copy" {
                    Write-Host "[COPY]   $($t.Source)"
                    [IO.File]::Copy($t.Source, $t.Destination, $true)
                    Set-OutputTimes $t.Destination $t.CreationTime $t.LastWriteTime
                    $directOutput = $true
                }

                "CopyPhoto" {
                    Write-Host "[PHOTO COPY] $($t.Source)"
                    [IO.File]::Copy($t.Source, $t.Destination, $true)
                    Set-OutputTimes $t.Destination $t.CreationTime $t.LastWriteTime
                    $directOutput = $true
                }

                "ConvertPhoto" {
                    Write-Host "[PHOTO]  $($t.Source)"

                    # Auto-orient first. Landscape fits 4096x2160; portrait fits 2160x4096.
                    $box = if ($t.Width -ge $t.Height) { "4096x2160>" } else { "2160x4096>" }

                    $imMsg = & $magick $t.Source `
                        -auto-orient `
                        -filter Lanczos `
                        -resize $box `
                        -background white `
                        -alpha remove `
                        -alpha off `
                        -sampling-factor "4:4:4" `
                        -quality ([string]$jpegQuality) `
                        $temp 2>&1

                    if ($LASTEXITCODE -ne 0) {
                        # FFmpeg fallback for formats unsupported by this ImageMagick build.
                        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
                        $photoFilter = "scale='if(gte(iw,ih),min(iw,4096),min(iw,2160))':'if(gte(iw,ih),min(ih,2160),min(ih,4096))':force_original_aspect_ratio=decrease:force_divisible_by=2"
                        $r = Invoke-Ffmpeg -CommandArgs @(
                            "-y", "-hide_banner", "-loglevel", "error",
                            "-i", $t.Source,
                            "-frames:v", "1",
                            "-vf", $photoFilter,
                            "-q:v", "1",
                            $temp
                        )
                        if ($r.ExitCode -ne 0) {
                            throw "Photo conversion failed.`nImageMagick: $($imMsg -join "`n")`nFFmpeg: $($r.Message)"
                        }
                    }
                }

                "CopyVideo" {
                    Write-Host "[VIDEO COPY] $($t.Source)"
                    [IO.File]::Copy($t.Source, $t.Destination, $true)
                    Set-OutputTimes $t.Destination $t.CreationTime $t.LastWriteTime
                    $directOutput = $true
                }

                "RemuxVideo" {
                    Write-Host "[REMUX]  $($t.Source)"

                    $r = Invoke-Ffmpeg -CommandArgs @(
                        "-y", "-hide_banner", "-loglevel", "error",
                        "-noautorotate",
                        "-i", $t.Source,
                        "-map", "0:v:0",
                        "-map", "0:a?",
                        "-map_metadata", "0",
                        "-map_chapters", "0",
                        "-c", "copy",
                        "-movflags", "+faststart",
                        $temp
                    )

                    if ($r.ExitCode -ne 0) {
                        # Keep video lossless; only normalize incompatible audio.
                        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
                        $r = Invoke-Ffmpeg -CommandArgs @(
                            "-y", "-hide_banner", "-loglevel", "error",
                            "-noautorotate",
                            "-i", $t.Source,
                            "-map", "0:v:0",
                            "-map", "0:a?",
                            "-map_metadata", "0",
                            "-map_chapters", "0",
                            "-c:v", "copy",
                            "-c:a", "aac",
                            "-b:a", "128k",
                            "-movflags", "+faststart",
                            $temp
                        )
                    }

                    if ($r.ExitCode -ne 0) {
                        # Last fallback: full transcode if the video codec itself cannot be muxed into MP4.
                        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
                        $encArgs = Get-EncoderArgs $encoder $t.TargetBitrate
                        $ffArgs = [System.Collections.Generic.List[string]]::new()
                        @("-y", "-hide_banner", "-loglevel", "error", "-noautorotate",
                          "-i", $t.Source, "-map", "0:v:0", "-map", "0:a?",
                          "-map_metadata", "0", "-map_chapters", "0") |
                            ForEach-Object { $ffArgs.Add($_) }
                        $encArgs | ForEach-Object { $ffArgs.Add($_) }
                        $ffArgs.Add("-fps_mode"); $ffArgs.Add("passthrough")
                        $ffArgs.Add("-c:a"); $ffArgs.Add("aac")
                        $ffArgs.Add("-b:a"); $ffArgs.Add("128k")
                        $ffArgs.Add("-movflags"); $ffArgs.Add("+faststart")
                        $ffArgs.Add($temp)

                        $r = Invoke-Ffmpeg -CommandArgs $ffArgs.ToArray()
                    }

                    if ($r.ExitCode -ne 0) {
                        throw "Remux/transcode failed.`nCOMMAND:`n$($r.Command)`n`nFFMPEG OUTPUT:`n$($r.Message)"
                    }
                }

                "EncodeVideo" {
                    Write-Host "[ENCODE] $($t.Source)"

                    $encArgs = Get-EncoderArgs $encoder $t.TargetBitrate
                    $ffArgs = [System.Collections.Generic.List[string]]::new()

                    @(
                        "-y", "-hide_banner", "-loglevel", "error",
                        "-noautorotate",
                        "-i", $t.Source,
                        "-map", "0:v:0",
                        "-map", "0:a?",
                        "-map_metadata", "0",
                        "-map_chapters", "0"
                    ) | ForEach-Object { $ffArgs.Add($_) }

                    if ($t.NeedsResize) {
                        $videoFilter = "scale='if(gte(iw,ih),min(iw,1920),min(iw,1080))':'if(gte(iw,ih),min(ih,1080),min(ih,1920))':force_original_aspect_ratio=decrease:force_divisible_by=2"
                        $ffArgs.Add("-vf"); $ffArgs.Add($videoFilter)
                    }

                    $encArgs | ForEach-Object { $ffArgs.Add($_) }

                    $ffArgs.Add("-fps_mode"); $ffArgs.Add("passthrough")

                    if ($t.AllAudioAAC) {
                        $ffArgs.Add("-c:a"); $ffArgs.Add("copy")
                    }
                    else {
                        $ffArgs.Add("-c:a"); $ffArgs.Add("aac")
                        $ffArgs.Add("-b:a"); $ffArgs.Add("128k")
                    }

                    $ffArgs.Add("-movflags"); $ffArgs.Add("+faststart")
                    $ffArgs.Add($temp)

                    $r = Invoke-Ffmpeg -CommandArgs $ffArgs.ToArray()
                    if ($r.ExitCode -ne 0) {
                        throw "Video encode failed.`nCOMMAND:`n$($r.Command)`n`nFFMPEG OUTPUT:`n$($r.Message)"
                    }
                }

                default {
                    throw "Unknown task action: $($t.Action)"
                }
            }

            if (-not $directOutput) {
                if (-not [IO.File]::Exists($temp)) {
                    throw "Expected temporary output file was not created: $temp"
                }

                [IO.File]::Move($temp, $t.Destination, $true)
                Set-OutputTimes $t.Destination $t.CreationTime $t.LastWriteTime
            }

            if (-not [IO.File]::Exists($t.Destination)) {
                throw "Final output file was not created: $($t.Destination)"
            }

            $outFile = [IO.FileInfo]::new($t.Destination)
            $outFile.Refresh()

            [pscustomobject]@{
                Success     = $true
                Source      = $t.Source
                Destination = $t.Destination
                Action      = $t.Action
                BeforeBytes = [Int64]$t.SourceBytes
                AfterBytes  = [Int64]$outFile.Length
                Error       = ""
            }
        }
        catch {
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            [pscustomobject]@{
                Success     = $false
                Source      = $t.Source
                Destination = $t.Destination
                Action      = $t.Action
                BeforeBytes = [Int64]$t.SourceBytes
                AfterBytes  = 0L
                Error       = $_.Exception.Message
            }
        }
    } -ThrottleLimit $EncodeParallel
)

# ---- Summary ----
Write-Section "Finished"

$successes = @($results | Where-Object { $_.Success -eq $true })
$failures = @($results | Where-Object { $_.Success -ne $true })

# Manual accumulation is deliberate: it remains valid for 0, 1, or many results
# and does not depend on Measure-Object returning a summary object.
[Int64]$afterBytes = 0
[Int64]$successfulBeforeBytes = 0

foreach ($r in $successes) {
    $afterBytes += [Int64]$r.AfterBytes
    $successfulBeforeBytes += [Int64]$r.BeforeBytes
}

Write-Host ("Before: {0}  ({1} files)" -f (Format-Bytes $beforeBytes), $tasks.Count)
Write-Host ("After:  {0}  ({1} successful files)" -f (Format-Bytes $afterBytes), $successes.Count)

if ($failures.Count -eq 0) {
    [Int64]$savedBytes = $beforeBytes - $afterBytes
    [double]$savedPct = if ($beforeBytes -gt 0) {
        ($savedBytes / [double]$beforeBytes) * 100.0
    } else {
        0.0
    }

    if ($savedBytes -ge 0) {
        Write-Host ("Saved:  {0}  ({1:N1}%)" -f (Format-Bytes $savedBytes), $savedPct) -ForegroundColor Green
    }
    else {
        Write-Host ("Change: +{0}  ({1:N1}% larger)" -f (Format-Bytes (-$savedBytes)), (-$savedPct)) -ForegroundColor Yellow
    }
}
elseif ($successes.Count -gt 0) {
    [Int64]$successfulSavedBytes = $successfulBeforeBytes - $afterBytes
    [double]$successfulSavedPct = if ($successfulBeforeBytes -gt 0) {
        ($successfulSavedBytes / [double]$successfulBeforeBytes) * 100.0
    } else {
        0.0
    }

    Write-Host ("Successful source size: {0}" -f (Format-Bytes $successfulBeforeBytes))
    if ($successfulSavedBytes -ge 0) {
        Write-Host ("Saved on successful files: {0} ({1:N1}%)" -f (Format-Bytes $successfulSavedBytes), $successfulSavedPct) -ForegroundColor Green
    }
}
else {
    Write-Host "No output files were completed successfully." -ForegroundColor Red
}

$counts = $results | Group-Object Action | Sort-Object Name
Write-Host ""
foreach ($g in $counts) {
    Write-Host ("{0,-14} {1,6}" -f ($g.Name + ":"), $g.Count)
}

if ($failures.Count -gt 0) {
    $errorLog = Join-Path $OutputRoot "ArchiveMedia_errors.txt"
    $log = foreach ($f in $failures) {
        @"
SOURCE: $($f.Source)
DEST:   $($f.Destination)
ACTION: $($f.Action)
ERROR:
$($f.Error)

"@
    }
    Set-Content -LiteralPath $errorLog -Value $log -Encoding UTF8

    Write-Host ""
    Write-Host "FAILED: $($failures.Count) file(s)" -ForegroundColor Red
    Write-Host "Error log: $errorLog" -ForegroundColor Yellow
    Write-Host ""
    foreach ($f in $failures) {
        Write-Host ("FAILED FILE: " + $f.Source) -ForegroundColor Red
        Write-Host $f.Error -ForegroundColor Yellow
        Write-Host ""
    }
    Write-Host "Do not delete the originals until all failures are resolved." -ForegroundColor Yellow
}
else {
    Write-Host ""
    Write-Host "All $($successes.Count) files completed successfully." -ForegroundColor Green
    Write-Host "You can compare/check the output before replacing the originals." -ForegroundColor Green
}
