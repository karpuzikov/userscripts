@echo off
setlocal
title Archive Media Compressor

where winget.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: winget is not available.
    echo Install "App Installer" from Microsoft, then run this BAT again.
    echo.
    pause
    exit /b 1
)

set "PWSH="
where pwsh.exe >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%I in ('where pwsh.exe') do (
        if not defined PWSH set "PWSH=%%I"
    )
)

if not defined PWSH if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe"

if not defined PWSH (
    echo PowerShell 7 is required. Installing it with winget...
    winget install --id Microsoft.PowerShell --exact --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo ERROR: PowerShell 7 installation failed.
        pause
        exit /b 1
    )
)

if not defined PWSH if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe"

if not defined PWSH (
    where pwsh.exe >nul 2>&1
    if not errorlevel 1 (
        for /f "delims=" %%I in ('where pwsh.exe') do (
            if not defined PWSH set "PWSH=%%I"
        )
    )
)

if not defined PWSH (
    echo.
    echo ERROR: PowerShell 7 was installed but pwsh.exe could not be located.
    pause
    exit /b 1
)

if not exist "%~dp0ArchiveMedia.ps1" (
    echo ERROR: ArchiveMedia.ps1 must be in the same folder as this BAT file.
    pause
    exit /b 1
)

"%PWSH%" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0ArchiveMedia.ps1"

echo.
pause
